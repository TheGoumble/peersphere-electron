package testapp;

import dao.UserDAO;
import model.User;
import util.PasswordHasher;

import java.time.LocalDateTime;
import java.util.Optional;

public class MainTestDAO {

    public static void main(String[] args) {
        try {
            User u = new User();
            u.setName("Test User");
            u.setEmail("testuser@example.com");

            String hashed = PasswordHasher.hash("mypassword123");
            u.setPasswordHash(hashed);

            u.setCreatedAt(LocalDateTime.now());

            UserDAO userDAO = new UserDAO();
            int newId = userDAO.createUser(u);

            if (newId == -1) {
                System.out.println("Insert failed.");
                return;
            }

            System.out.println("Inserted user with ID: " + newId);

            Optional<User> loaded = userDAO.getUserByEmail("testuser@example.com");

            if (loaded.isPresent()) {
                User fetched = loaded.get();
                System.out.println("Loaded user from DB:");
                System.out.println("   ID: " + fetched.getUserId());
                System.out.println("   Name: " + fetched.getName());
                System.out.println("   Email: " + fetched.getEmail());
                System.out.println("   Hash: " + fetched.getPasswordHash());
                System.out.println("   CreatedAt: " + fetched.getCreatedAt());
            } else {
                System.out.println("Could not load user by email.");
            }

        } catch (Exception e) {
            System.out.println("Error during DAO test: " + e.getMessage());
            e.printStackTrace();
        }
    }
}